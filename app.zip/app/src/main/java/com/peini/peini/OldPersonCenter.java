package com.peini.peini;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class OldPersonCenter extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_old_person_center);
    }
}
