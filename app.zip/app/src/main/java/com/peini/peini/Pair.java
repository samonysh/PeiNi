package com.peini.peini;

/**
 * Created by Administrator on 2017/8/22.
 */

public class Pair {
    private User old;
    private User young;

    public Pair(User old, User young) {
        this.old = old;
        this.young = young;
    }


}
