package com.peini.peini;

/**
 * Created by Administrator on 2017/9/9.
 */

public class PersonData {
    public static String userName = null;
}
